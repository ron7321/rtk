<?php
include_once "connect.php";
include_once "header.php";
?>
<main>
	<h1 class="mb-5">Отзывы</h1>
	<hr class="liner">
	<div class="container">
		Здесь отзывы
	</div>
</main>
<?php
include_once "footer.php";
?>